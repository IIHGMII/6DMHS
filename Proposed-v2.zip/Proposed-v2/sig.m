function y = sig(x)
    y = ( sign(x) + 1 ) / 2;
end