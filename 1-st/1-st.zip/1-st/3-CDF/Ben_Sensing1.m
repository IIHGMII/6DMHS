function [ek, error_ben1,error_theta,error_phi,error_varphi] = Ben_Sensing1(B,M,K,V_F,h,lambda,eta0,delta_x,Mx,Coor_Ele,e0)
%文章Near-field Localization with Dynamic Metasurface Antennas中得全息感知方法

for b =1:B, mm(:,b) = rand(M,1); end
% for b =1:B, mm(:,b) = 1 * randn(M,1) +  1j * randn(M,1); end

for k = 1 : K

%上行接收信号
y1 = zeros(1,1); 
for b = 1:B
    y1 = y1 + mm(:,b).' * diag(V_F) *h{k,b} ;
end


psi3 = rand(B,1); V_F000 = sparse(diag(V_F));
for ITE_NUM = 1:3
    if ITE_NUM == 1
for ite_num = 1:6

cvx_begin quiet
cvx_solver mosek
variable mm(M,B)
variable PE0(1)
expression PE(B,1)

for b = 1:B
    PE(b,1) = 2*real( psi3(b)' * mm(:,b).' * V_F000 *h{k,b} ) - abs( psi3(b) )^2;
end

maximize PE0

subject to

sum(PE(:)) >= PE0;

0 <= mm <= 1;

for b = 1:B
    eta0 * sum( mm(:,b).^2 ) <= 1;
end

cvx_end

for b = 1:B
    psi3(b) = mm(:,b).' * V_F000 *h{k,b};
end

PE_ite(ite_num) = cvx_optval;

end
    end

for b = 1:B
    aa{b} = @(theta,phi) exp( 1j * 2*pi/lambda * Coor_Ele{b} * [ sin(phi) * cos(theta) ; sin(phi) * sin(theta) ; cos(phi) ] ); 
end

% ddd = delta_x / (Mx/2) * pi ;
ddd = [ -1: 1/Mx : 1 ] * pi;
for i1 =  1:length(ddd) 
    theta0 = ddd(i1);
    for j1 =  1:length(ddd)
        phi0 = ddd(j1);
        % PRHS(i1,j1) = ( mm(:,1).' * V_F000 * aa{1}(theta0,phi0) )' * mm(:,1).' * V_F000 * h{k,1} + ( mm(:,2).' * V_F000 * aa{2}(theta0,phi0) )' * mm(:,2).' * V_F000 * h{k,2} + ( mm(:,3).' * V_F000 * aa{3}(theta0,phi0) )' * mm(:,3).' * V_F000 * h{k,3} + ( mm(:,4).' * V_F000 * aa{4}(theta0,phi0) )' * mm(:,4).' * V_F000 * h{k,4} + ( mm(:,5).' * V_F000 * aa{5}(theta0,phi0) )' * mm(:,5).' * V_F000 * h{k,5} + ( mm(:,6).' * V_F000 * aa{6}(theta0,phi0) )' * mm(:,6).' * V_F000 * h{k,6} + ( mm(:,7).' * V_F000 * aa{7}(theta0,phi0) )' * mm(:,7).' * V_F000 * h{k,7} + ( mm(:,8).' * V_F000 * aa{8}(theta0,phi0) )' * mm(:,8).' * V_F000 * h{k,8} ;
        PRHS(i1,j1) = ( mm(:,1).' * V_F000 * aa{1}(theta0,phi0) )' * mm(:,1).' * V_F000 * h{k,1} + ( mm(:,2).' * V_F000 * aa{2}(theta0,phi0) )' * mm(:,2).' * V_F000 * h{k,2} + ( mm(:,3).' * V_F000 * aa{3}(theta0,phi0) )' * mm(:,3).' * V_F000 * h{k,3} + ( mm(:,4).' * V_F000 * aa{4}(theta0,phi0) )' * mm(:,4).' * V_F000 * h{k,4} + ( mm(:,5).' * V_F000 * aa{5}(theta0,phi0) )' * mm(:,5).' * V_F000 * h{k,5} + ( mm(:,6).' * V_F000 * aa{6}(theta0,phi0) )' * mm(:,6).' * V_F000 * h{k,6}  ;
        angle_R{i1,j1} = [ sin(phi0) * cos(theta0) ; sin(phi0) * sin(theta0) ; cos(phi0) ];
    end
end

A = PRHS(:,:);
[maxValue, linearIndex] = max(A(:)); 
[row, col] = ind2sub(size(A), linearIndex);
index1 = row;
index2 = col;
%     ek(:,k) =  sin(ddd(index2(k))) * cos(ddd(index1(k))) ; sin(ddd(index2(k))) * sin(ddd(index1(k))) ; cos(ddd(index1(k)))^2  ;
ek = angle_R{index1,index2};


end

error_ben1(k,1) =  norm(ek - e0{k}) ;
error_theta= ek(1) - e0{k}(1);
error_phi =ek(2) - e0{k}(2);
error_varphi = ek(3) - e0{k}(3);


end



end