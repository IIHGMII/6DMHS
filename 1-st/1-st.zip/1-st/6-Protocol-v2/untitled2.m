clc;clear;
K_rice = 10;
[P_out] = test_6DMA_Proposed(K_rice)