function [Coor_Ele,normal_vector,Rot_Matrix,q] = Orientation_Initial(B,Coor_Ele_init,flag)
%此处，在空间中均匀生成B个点数，让全息超表面均匀的在自由空间中排列
[X, Y, Z] = Orientation_uniformSpherePoints(B);
% 初始法向量
n1 = [0;0;1];   %am1 = [ 0.02 ; 0.01 ; sqrt( 1 - 0.02^2 -0.01^2 ) ];
% am1 = [ 0.785274214447971 ; -0.450409690531451 ; 0.424824103363362 ];
% am1 = [0;0;1];
% am1 = [ -0.279137967577308 ; 0.230923009632481 ; 0.934359478573196 ];
% am1 = [ -0.278445348362427 ; 0.236305977207617 ; 0.930928393116936 ];  %优化馈源位置，最佳方向
am1 = [ -0.285894092386310 ; 0.236512162150458 ; 0.928615402141017 ]; %随机馈源位置，最佳方向
% am1 = [  -0.477630009460290
%    0.843521030655574
%    0.245645771192427];
for b = 1:B
    % 平移变量
    q(b,:) = [X(b) , Y(b) , Z(b) ];
    % 目标单位的法向量,并归一化
    n2 = [X(b) ; Y(b) ; Z(b) ]; n2 = n2 / norm(n2);
    if norm(n2 - n1) <= 1e-3
        Coor_Ele{b} = q(b,:) + Coor_Ele_init;   %此时UPA的法向量为[0;0;1]
        normal_vector{b} = q(b,:).'; 
        Rot_Matrix{b} = eye(3);
        am2{b} = Rot_Matrix{b} * am1;
    elseif norm(n2 + n1) <= 1e-3
        Coor_Ele{b} = q(b,:) + Coor_Ele_init;   %此时UPA的法向量为[0;0;-1]
        normal_vector{b} = q(b,:).'; 
        Rot_Matrix{b} = [ 1,0,0;0,1,0;0,0,-1 ];
        am2{b} = Rot_Matrix{b} * am1;
    else
    % 计算旋转轴(叉乘),并归一化
    u = cross(n1,n2);   u = u / norm(u);
    % 计算旋转角度（弧度单位）
    alph = acos( n1.' * n2 );
    % 计算矩阵U
    U = [ 0    , -u(3) , u(2) ; ...
          u(3) , 0     , -u(1); ...
          -u(2), u(1)  , 0          ];
    % 计算罗德格里斯旋转矩阵
    Rot_Matrix{b} = cos(alph) * eye(3) + ( 1 - cos(alph) ) * ( u * u.' ) + sin(alph) * U;
    Coor_Ele{b} = q(b,:) + Coor_Ele_init * Rot_Matrix{b}.';
    normal_vector{b} = q(b,:).'; 
    am2{b} = Rot_Matrix{b} * am1;
    end
end

if flag == 1
% % 展示6DMA空间图
figure(2);
for b =1:B
scatter3(Coor_Ele{b}(:,1), Coor_Ele{b}(:,2), Coor_Ele{b}(:,3), 'filled')
hold on;
end
end

end